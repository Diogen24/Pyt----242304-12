#Группа Pytн-КБд-242304-12
#Петрухин Сергей Игоревич 
import pygame
import random
import sys
import os

pygame.init()

game_dir=os.path.dirname(os.path.abspath(__file__))
print(game_dir)
SIZE_BLOCK=20
COUNT_BLOCKS=20
MARGIN=0
HEADER_MARGIN=70
FOOTER_MARGIN=100
DIRECTION_LIST=['up','down','left','right']
COLOR_LIST = {
# Цвета (R, G, B)
'Чёрный':(0, 0, 0),
'Белый':(255, 255, 255),
'Красный':(255, 0, 0),
'Зелёный':(0, 255, 0),
'Синий':(0, 0, 255),
'Мокрый асфальт':(96,96,96),
'Серый':(128,128,128),
'Тёмно-зелёный':(0,69,36),
'Изумрудный':(80,200,120),
'Жёлтый':(255,255,0)
}

# WIN_SIZE=(440,440)

WIN_SIZE=[SIZE_BLOCK*COUNT_BLOCKS+2*SIZE_BLOCK+MARGIN*COUNT_BLOCKS,
          SIZE_BLOCK*COUNT_BLOCKS+2*SIZE_BLOCK+MARGIN*COUNT_BLOCKS+HEADER_MARGIN+FOOTER_MARGIN]

BACK_SIZE=[SIZE_BLOCK*COUNT_BLOCKS+MARGIN*COUNT_BLOCKS,
          SIZE_BLOCK*COUNT_BLOCKS+MARGIN*COUNT_BLOCKS]
score=0
difficulty=3
boost=False
music_flag=True
sound_flag=True
screen=pygame.display.set_mode(WIN_SIZE)
pygame.display.set_caption('Змейка')
timer=pygame.time.Clock()
font=pygame.font.SysFont('ComicSans',16)
#region load sound
pygame.mixer.music.load(f'{game_dir}/sound/house_lo.wav')
pygame.mixer.music.play(-1)
sound_eat=pygame.mixer.Sound(f'{game_dir}/sound/whiff.wav')
sound_crash=pygame.mixer.Sound(f'{game_dir}/sound/boom.wav')
#endregion
#region load textures
apple_image=pygame.image.load(f'{game_dir}/texture/apple.png')
head_up_image=pygame.image.load(f'{game_dir}/texture/head_up.png')
head_down_image=pygame.image.load(f'{game_dir}/texture/head_down.png')
head_left_image=pygame.image.load(f'{game_dir}/texture/head_left.png')
head_right_image=pygame.image.load(f'{game_dir}/texture/head_right.png')
tail_up_image=pygame.image.load(f'{game_dir}/texture/tail_up.png')
tail_down_image=pygame.image.load(f'{game_dir}/texture/tail_down.png')
tail_left_image=pygame.image.load(f'{game_dir}/texture/tail_left.png')
tail_right_image=pygame.image.load(f'{game_dir}/texture/tail_right.png')
body_horizontal_image=pygame.image.load(f'{game_dir}/texture/body_horizontal.png')
body_vertical_image=pygame.image.load(f'{game_dir}/texture/body_vertical.png')
body_bottomleft_image=pygame.image.load(f'{game_dir}/texture/body_bottomleft.png')
body_bottomright_image=pygame.image.load(f'{game_dir}/texture/body_bottomright.png')
body_topleft_image=pygame.image.load(f'{game_dir}/texture/body_topleft.png')
body_topright_image=pygame.image.load(f'{game_dir}/texture/body_topright.png')
noway_image=pygame.image.load(f'{game_dir}/texture/noway.png')
background_image=pygame.image.load(f'{game_dir}/texture/grass.png')
controls_image=pygame.image.load(f'{game_dir}/texture/controls.png')
#endregion

background_image=pygame.transform.scale(background_image, BACK_SIZE)

class SnakeBlock:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def is_inside(self):
        return 0<=self.x<SIZE_BLOCK and 0<=self.y<SIZE_BLOCK
    def __eq__(self,other):
        return isinstance(other,SnakeBlock) and self.x==other.x and self.y==other.y

def get_random_empty_block():
    x=random.randint(0,COUNT_BLOCKS-1)
    y=random.randint(0,COUNT_BLOCKS-1)
    empty_block=SnakeBlock(x,y)
    while empty_block in snake_block:
        empty_block.x=random.randint(0,COUNT_BLOCKS-1)
        empty_block.y=random.randint(0,COUNT_BLOCKS-1)
    return empty_block

# def draw_block(color,row,column):
#     pygame.draw.rect(screen,color,[SIZE_BLOCK+column*SIZE_BLOCK+MARGIN*(column+1),
#                                            HEADER_MARGIN+SIZE_BLOCK+row*SIZE_BLOCK+MARGIN*(row+1),
#                                            SIZE_BLOCK,
#                                            SIZE_BLOCK])
    
def draw_texture(image,row,column):
    screen.blit(image,(SIZE_BLOCK/2+column*SIZE_BLOCK+MARGIN*(column+1),
                                           HEADER_MARGIN+SIZE_BLOCK/2+row*SIZE_BLOCK+MARGIN*(row+1)))

snake_block=[SnakeBlock(0,0),SnakeBlock(random.randint(3,COUNT_BLOCKS-3),random.randint(3,COUNT_BLOCKS-3))]
apple=get_random_empty_block()
#region random direction
direction=random.choice(DIRECTION_LIST)
if direction=='up':
    d_row=-1
    d_col=0
elif direction=='down':
    d_row=1
    d_col=0
elif direction=='left':
    d_row=0
    d_col=-1
elif direction=='right':
    d_row=0
    d_col=1
#endregion
while True:
    #region controls
    key=pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            print('exit')
            pygame.quit()
            sys.exit()
        elif event.type==pygame.KEYDOWN:
            if event.key==pygame.K_m and music_flag==True:
                music_flag=not music_flag
                pygame.mixer.music.pause()
            elif event.key==pygame.K_m and music_flag==False:
                music_flag=not music_flag
                pygame.mixer.music.unpause()
            if event.key==pygame.K_s:
                sound_flag=not sound_flag
            if event.key==pygame.K_p:
                paused=not paused
            if event.key==pygame.K_UP and d_col!=0:
                d_row=-1
                d_col=0
                direction='up'
                break
            elif event.key==pygame.K_DOWN and d_col!=0:
                d_row=1
                d_col=0
                direction='down'
                break
            elif event.key==pygame.K_LEFT and d_row!=0:
                d_row=0
                d_col=-1
                direction='left'
                break
            elif event.key==pygame.K_RIGHT and d_row!=0:
                d_row=0
                d_col=1
                direction='right'
                break
    #endregion
    screen.blit(background_image,(SIZE_BLOCK,SIZE_BLOCK+HEADER_MARGIN))
    pygame.draw.rect(screen,COLOR_LIST['Мокрый асфальт'],[0,0,WIN_SIZE[0],HEADER_MARGIN])
    pygame.draw.rect(screen,COLOR_LIST['Чёрный'],[0,HEADER_MARGIN+SIZE_BLOCK*COUNT_BLOCKS+2*SIZE_BLOCK+MARGIN*COUNT_BLOCKS,WIN_SIZE[0],FOOTER_MARGIN])
    draw_texture(controls_image,COUNT_BLOCKS+2,0)
    

    #if inside
    head=snake_block[-1]
    if not head.is_inside():
            print('out of bounds')
            if sound_flag==True:
                sound_crash.play()
            pygame.time.delay(2000)
            pygame.quit()
            sys.exit()
    #eat apple
    pop=True    
    if apple==head:
        if sound_flag==True:
            sound_eat.play()
        apple=get_random_empty_block()
        score+=1
        pop=False
        if score%1==0:
            difficulty+=0.5
    #movement
    if pop==True:
        snake_block.pop(0)
        pop=True
    new_head=SnakeBlock(head.x+d_row,head.y+d_col)
    snake_block.append(new_head)
    #eat self
    if new_head in snake_block[:-1]:
            print('uroboros')
            if sound_flag==True:
                sound_crash.play()
            pygame.time.delay(2000)
            pygame.quit()
            sys.exit()
    #draw borderline
    for row in range(COUNT_BLOCKS+2):
        for column in range(COUNT_BLOCKS+2):
            if not(0<row<COUNT_BLOCKS+1 and 0<column<COUNT_BLOCKS+1):
                draw_texture(noway_image,row-1,column-1)
    
    draw_texture(apple_image,apple.x,apple.y)      
    #snake animation
    for block in snake_block:
        if block==snake_block[0]:
            if snake_block[1].y==snake_block[0].y+1:
                draw_texture(tail_left_image,block.x,block.y)
            elif snake_block[1].y==snake_block[0].y-1:
                draw_texture(tail_right_image,block.x,block.y)
            elif snake_block[1].x==snake_block[0].x+1:
                draw_texture(tail_up_image,block.x,block.y)
            elif snake_block[1].x==snake_block[0].x-1:
                draw_texture(tail_down_image,block.x,block.y)
        if block!=snake_block[0] and block!=snake_block[-1]:
            if (block.x+1==snake_block[snake_block.index(block)+1].x or block.x+1==snake_block[snake_block.index(block)-1].x) and (block.y-1==snake_block[snake_block.index(block)+1].y or block.y-1==snake_block[snake_block.index(block)-1].y):
                draw_texture(body_bottomleft_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)
            elif (block.x+1==snake_block[snake_block.index(block)+1].x or block.x+1==snake_block[snake_block.index(block)-1].x) and (block.y+1==snake_block[snake_block.index(block)+1].y or block.y+1==snake_block[snake_block.index(block)-1].y):
                draw_texture(body_bottomright_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)
            elif (block.x-1==snake_block[snake_block.index(block)+1].x or block.x-1==snake_block[snake_block.index(block)-1].x) and (block.y-1==snake_block[snake_block.index(block)+1].y or block.y-1==snake_block[snake_block.index(block)-1].y):
                draw_texture(body_topleft_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)
            elif (block.x-1==snake_block[snake_block.index(block)+1].x or block.x-1==snake_block[snake_block.index(block)-1].x) and (block.y+1==snake_block[snake_block.index(block)+1].y or block.y+1==snake_block[snake_block.index(block)-1].y):
                draw_texture(body_topright_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)
            elif snake_block[snake_block.index(block)].x==snake_block[snake_block.index(block)-1].x:
                draw_texture(body_horizontal_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)    
            elif snake_block[snake_block.index(block)].y==snake_block[snake_block.index(block)-1].y:
                draw_texture(body_vertical_image,snake_block[snake_block.index(block)].x,snake_block[snake_block.index(block)].y)
        if block==snake_block[-1]:
            if direction=='right':
                draw_texture(head_right_image,block.x,block.y)
            elif direction=='down':
                draw_texture(head_down_image,block.x,block.y)
            elif direction=='left':
                draw_texture(head_left_image,block.x,block.y)
            elif direction=='up':
                draw_texture(head_up_image,block.x,block.y)
    #print score
    text_score=font.render(f'Score: {score} Speed: {difficulty} Music: {music_flag} Sound: {sound_flag}',0,COLOR_LIST['Белый'])
    screen.blit(text_score,(SIZE_BLOCK,SIZE_BLOCK))
    
    pygame.display.flip()
        
    if key[pygame.K_LSHIFT]:
        boost=True
    if boost:
        timer.tick(difficulty*2)
        boost=False
    else:
        timer.tick(difficulty)