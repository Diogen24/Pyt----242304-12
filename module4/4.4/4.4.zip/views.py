from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    a='''<a href="http://127.0.0.1:8000/pages/page1">Первая фраза, которую выдаёт функция</a><br>
    <a href="http://127.0.0.1:8000/pages/page2">Вторая фраза, которую выдаёт функция</a>'''
    return HttpResponse(a)

def phrase1(request):
    a='''<a href="http://127.0.0.1:8000/pages/page2">Первая фраза, которую выдаёт функция</a><br>
    <a href="http://127.0.0.1:8000">На главную</a>'''
    return HttpResponse(a)

def phrase2(request):
    a='''<a href="http://127.0.0.1:8000/pages/page1">Вторая фраза, которую выдаёт функция</a><br>
    <a href="http://127.0.0.1:8000">На главную</a>'''
    return HttpResponse(a)

# Create your views here.
